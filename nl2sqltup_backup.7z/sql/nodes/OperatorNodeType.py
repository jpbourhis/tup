class OperatorNodeType(object):
    EQUAL = "="
    LESS_THAN = "<"
    GREATER_THAN = ">"
