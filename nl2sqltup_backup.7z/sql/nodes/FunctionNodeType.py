class FunctionNodeType(object):
    COUNT = "COUNT"
