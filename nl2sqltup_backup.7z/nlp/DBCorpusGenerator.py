import cPickle as pickle
from nlp import Tokenizer
from database.Node import Node

class DBCorpusGenerator(object):
    """
    Generate a corpus based on the database
    """
    def __init__(self, jar_path):
        self.tokenizer = Tokenizer(jar_path)


    def create_db_corpus(self, database, path):
        print "Create_db_corpus"
        print path

        tables = {
            'campuses': ['location'],
            'courses': ['peoplesoft_course_id', 'name'],
            'faculty': ['first_name', 'last_name', 'name'],
            'sections': ['section_number'],
            'students': ['first_name', 'last_name', 'name', 'university_id', 'net_id', 'email'],
            'terms': ['semester', 'year']
        }

        corpus = []
        for table in tables:
            print "SELECT %s FROM %s" % (", ".join(tables[table]), table)
            #SELECT semester, year FROM terms

            cursor = database.execute("SELECT %s FROM %s" % (", ".join(tables[table]), table))
            rows = cursor.fetchall()

            for row in rows:
                sentence = []
                for i, value in enumerate(row):
                    # label : students.first_name,students.last_name,students.name,Jeffrey,Watts
                    label = "%s.%s" % (table, tables[table][i])
                    print "label: {}" .format(label)
                    if " " in str(value):
                        tokens = self.tokenizer.tokenize(value)
                        for token in tokens:
                            sentence.append((token, label))
                    else:
                        sentence.append((value, label))
                # [('Donald', 'students.first_name'), ('Murphy', 'students.last_name'), (u'Donald', 'students.name'), (u'Murphy', 'students.name'), ('N582063738', 'students.university_id'), ('dm6993', 'students.net_id'), ('dm6993@nyu.edu', 'students.email')]
                print ">>>sentence {}<<<" .format(sentence)
                corpus.append(sentence)

        pickle.dump(corpus, open(path, "wb"))

    def  construct_without_id(self, database, path):


        """
        print "Create_db_corpus V1, here is only 6 Tables, why ?"



        tables = {
            'campuses': ['location'],
            'courses': ['peoplesoft_course_id', 'name'],
            'faculty': ['first_name', 'last_name', 'name'],
            'sections': ['section_number'],
            'students': ['first_name', 'last_name', 'name', 'university_id', 'net_id', 'email'],
            'terms': ['semester', 'year']
        }

        corpus = []
        table_old=[]
        old_sentences=[]

        print "OLD VERSION"
        for table in tables:
            if table=="terms":
                #print "SELECT %s FROM %s" % (", ".join(tables[table]), table)
                cursor = database.execute("SELECT %s FROM %s" % (", ".join(tables[table]), table))
                rows = cursor.fetchall()
                #print "Table: {}" .format(table)
                table_old.append(table)

                for row in rows:
                    sentence = []
                    for i, value in enumerate(row):
                        # label : students.first_name,students.last_name,students.name,Jeffrey,Watts
                        label = "%s.%s" % (table, tables[table][i])
                        #print "label: {}".format(label)
                        if " " in str(value):
                            tokens = self.tokenizer.tokenize(value)
                            for token in tokens:
                                sentence.append((token, label))
                                old_sentences.append((token, label))
                        else:
                            sentence.append((value, label))
                            old_sentences.append((value, label))
                    # [('Donald', 'students.first_name'), ('Murphy', 'students.last_name'), (u'Donald', 'students.name'), (u'Murphy', 'students.name'), ('N582063738', 'students.university_id'), ('dm6993', 'students.net_id'), ('dm6993@nyu.edu', 'students.email')]
                    print ">>>sentence {}<<<".format(sentence)
                    corpus.append(sentence)


        print ">>>>>>>>>>>>><<<<<<<<<<<<<<<<"
        print ">>>>>>>>>>>>><<<<<<<<<<<<<<<<"
        print ">>>>>>>>>>>>><<<<<<<<<<<<<<<<"


        """
        # TO ADAPT FOR THE NEW VERSION
        print "Starting New Version which has 7"
        corpus = []
        table_new = []
        new_sentences = []
        for (table_name,) in database.get_tables():

                fields = database.get_fields(table_name)
                fieldnames = []
                table_new.append(table_name)
                for field in fields:
                    #print field[0]
                    if not field[0] == "id":
                        fieldnames.append(field[0]) # Save Fieldnames

                #print "SELECT %s FROM %s" % (", ".join(fieldnames), table_name)
                cursor = database.execute("SELECT %s FROM %s" % (", ".join(fieldnames), table_name))
                rows = cursor.fetchall()

                for row in rows:
                    #print "rows"
                    sentence = []
                    for i, value in enumerate(row):
                        # label : students.first_name,students.last_name,students.name,Jeffrey,Watts
                        label = "%s.%s" % (table_name, fieldnames[i])
                        #print "label: {}".format(label)
                        if " " in str(value):
                            tokens = self.tokenizer.tokenize(value)
                            for token in tokens:
                                sentence.append((token, label))
                                new_sentences.append((token, label))
                        else:
                            sentence.append((value, label))
                            #new_sentences((value, label))
                    # [('Donald', 'students.first_name'), ('Murphy', 'students.last_name'), (u'Donald', 'students.name'), (u'Murphy', 'students.name'), ('N582063738', 'students.university_id'), ('dm6993', 'students.net_id'), ('dm6993@nyu.edu', 'students.email')]
                    #print ">>>sentence {}<<<".format(sentence)
                    corpus.append(sentence)

        pickle.dump(corpus, open(path, "wb"))

        #print "Ending"
        #print ">>>>>>><<<<<<<"
        #print "Table OLD {}" .format(table_old)
        #print "Table New {}" .format(table_new)
        #print *old_sentences, sep="\n"
        #print old_sentences[0]
        #print "old sentences {} " .format(old_sentences[1])
       # print "new sentences {} " .format(new_sentences[0])

