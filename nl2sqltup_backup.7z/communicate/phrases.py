GREETINGS = [
    'How can I help you?',
    'What can I do for you today?',
    'AMAA (Ask me almost anything)'
]

CONTINUATIONS = [
    'Anything else?',
    'What else would you like to know?',
    'What else?'
]

ANSWERS = {
    'yes': True,
    'y': True,
    'no': False,
    'n': False
}
